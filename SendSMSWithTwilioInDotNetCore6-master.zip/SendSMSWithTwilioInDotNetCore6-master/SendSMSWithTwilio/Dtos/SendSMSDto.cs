﻿namespace SendSMSWithTwilio.Dtos
{
    public class SendSMSDto
    {
        public string MobileNumber { get; set; }
        public string Body { get; set; }
    }
}